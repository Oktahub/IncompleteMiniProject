package com.iss.pages.crm.accounts;

import org.openqa.selenium.By;

import com.iss.base.Page;
import com.iss.base.TopMenu;

public class AccountsPage extends Page{
	
	TopMenu menu = new TopMenu();
	
	public CreateAccountPage goToCreateAccounts() {
		driver.findElement(By.cssSelector("q")).click();
		
		return new CreateAccountPage();
		
	}
	
	public void goToImportAccounts() {
		
	}

}
