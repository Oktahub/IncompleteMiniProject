package com.iss.pages;

import org.openqa.selenium.By;

import com.iss.base.Page;

public class LoginPage extends Page{
	
	
	public AppPage doLogin(String username, String password) {
		driver.switchTo().frame("zohoiam");
		driver.findElement(By.cssSelector("#lid")).sendKeys(username);
		driver.findElement(By.cssSelector("#pwd")).sendKeys(password);
		driver.findElement(By.cssSelector("#submit_but")).click();
		
		return new AppPage();
		
	}
	
	public void goToSalesAndMarketing() {
		
	}

}
