package com.iss.pages;

import org.openqa.selenium.By;

import com.iss.base.Page;

public class AppPage extends Page{
	
	
	
	public void goToChat() {
		driver.findElement(By.cssSelector("x")).click();
		
	}
	
	public crmHomePage goToCRM() {
		driver.findElement(By.cssSelector("y")).click();
		
		return new crmHomePage();
		
	}
	
	public void goToSalesIQ() {
		driver.findElement(By.cssSelector("z")).click();
		
	}

}
