package com.iss.pages.crm.accounts;

import com.iss.base.Page;
import com.iss.base.TopMenu;

public class ImportAccountPage extends Page{
	
	TopMenu menu = new TopMenu();

}
