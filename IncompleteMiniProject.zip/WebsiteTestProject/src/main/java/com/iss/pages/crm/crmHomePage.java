package com.iss.pages.crm;

import com.iss.base.Page;

public class crmHomePage extends Page{
	
	public void verifyAddSampleDataBtn() {
		
	}
	
	public void verifyTextCrmHome() {
		
	}

}
