package com.iss.pages.crm.accounts;

import org.openqa.selenium.By;

import com.iss.base.Page;
import com.iss.base.TopMenu;

public class CreateAccountPage extends Page{
	
	TopMenu menu = new TopMenu(String accountName);
	
	public void createAccount() {
		driver.findElement(By.cssSelector("z")).sendKeys(accountName);
		
	}

}
