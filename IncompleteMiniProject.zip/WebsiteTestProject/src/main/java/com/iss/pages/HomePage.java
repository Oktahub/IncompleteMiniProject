package com.iss.pages;

import org.openqa.selenium.By;

import com.iss.base.Page;

public class HomePage extends Page{
	
	
	public void goToSupport() {
		driver.findElement(By.cssSelector(".signing>a:nth-child(2)")).click();
		
	}
	
	public void goToSignUp() {
		driver.findElement(By.cssSelector(".signup")).click();
		
	}
	
	public LoginPage goToLogin() {
		driver.findElement(By.cssSelector(".signin")).click();
		
		return new LoginPage();
		
	}
	
	public void goToZohoEdu() {
		
	}
	
	public void goToLearnMore() {
		
	}
	
	public void validateFooterLinks() {
		
	}

}
