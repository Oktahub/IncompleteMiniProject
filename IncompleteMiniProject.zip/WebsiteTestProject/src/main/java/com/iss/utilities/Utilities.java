package com.iss.utilities;

public class Utilities {

}
