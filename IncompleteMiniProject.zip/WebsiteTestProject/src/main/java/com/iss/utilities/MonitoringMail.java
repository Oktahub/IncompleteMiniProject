package com.iss.utilities;

public class MonitoringMail {

}
