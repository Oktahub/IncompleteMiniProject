package com.iss.rough;

import com.iss.base.Page;
import com.iss.pages.AppPage;
import com.iss.pages.HomePage;
import com.iss.pages.LoginPage;
import com.iss.pages.crm.crmHomePage;
import com.iss.pages.crm.accounts.AccountsPage;
import com.iss.pages.crm.accounts.CreateAccountPage;

public class LoginTest {
	
	public static void main (String[] args) {
	
		
		HomePage home = new HomePage();
		LoginPage lp = home.goToLogin();
		
		AppPage app = lp.doLogin("AccessG", "123Group");
		app.goToCRM();
		
		AccountsPage account = Page.menu.goToAccounts();
		
		CreateAccountPage cap = account.goToCreateAccounts();
		
		cap.createAccount("AccessGroup");
		
	}

}
